define(["../head.js"], function (_head) {
  "use strict";

  function _templateObject_d7415600495211e98f33d7313858de80() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <style include=\"global-style\">\n      :host{\n        display: block;\n        font-size: 14px;\n        line-height: 1.3;\n        color: #28344f;\n        position: absolute;\n        top: 0;\n        left: 0;\n        width: 100%;\n        height: 100%;\n        z-index: 2;\n      }\n      :host > .In{\n        position: absolute;\n        top: 56px;\n        right: 0px;\n        bottom: 0px;\n        left: 0px;\n        border: 1px solid transparent;\n        border-width: 5px 4px 5px;\n      }\n      :host > .In > .Bg{\n        position: absolute;\n        top:-3px;\n        right:-4px;\n        bottom:-5px;\n        left:-4px;\n        font-size: 0;\n        overflow: hidden;\n      }\n      :host > .In > .Bg > .t,\n      :host > .In > .Bg > .b{\n        height: 11px;\n        text-indent: -9999px;\n        background: url('/images/popup_white/bg_h.png') 0 -22px repeat-x;\n        position: absolute;\n        left: 11px;\n        right: 11px;\n      }\n      :host > .In > .Bg > .t{\n        top: 0;\n      }\n      :host > .In > .Bg > .b{\n        bottom: 0;\n        background-position: 0 -55px;\n      }\n      :host > .In > .Bg > .t:before,\n      :host > .In > .Bg > .b:before,\n      :host > .In > .Bg > .t:after,\n      :host > .In > .Bg > .b:after{\n        content: '';\n        display: block;\n        position: absolute;\n        top: 0;\n        width: 11px;\n        overflow:hidden;font-size:0;text-indent:-9999px;height:0;padding-top:11px;\n        background: url('/images/popup_white/bg_h.png') 0 0 no-repeat;\n      }\n      :host > .In > .Bg > .t:before,\n      :host > .In > .Bg > .b:before{\n        left: -11px;\n        background-position-x: 0;\n      }\n      :host > .In > .Bg > .t:after,\n      :host > .In > .Bg > .b:after{\n        right: -11px;\n        background-position-x: 100%;\n      }\n      :host > .In > .Bg > .t:after{\n        background-position-y: -11px;\n      }\n      :host > .In > .Bg > .b:before{\n        background-position-y: -33px;\n      }\n      :host > .In > .Bg > .b:after{\n        background-position-y: -44px;\n      }\n\n      :host > .In > .Bg > .m{\n        position: absolute;\n        top:11px;right:-4px;bottom:11px;left:0px;\n        background:\n          url('/images/popup_white/bg_v.png') -4px 0 repeat-y,\n          url('/images/popup_white/bg_v.png') 100% 0 repeat-y;\n      }\n      :host > .In > .Bg:after{\n        content: '';\n        display: block;\n        position: absolute;\n        top:3px;\n        right:4px;\n        bottom:5px;\n        left:4px;\n        background: #fff;\n        border-radius: 4px;\n      }\n\n      :host > .In > .In{\n        position: relative;\n        display: table;\n        width: 100%;\n        height: 100%;\n      }\n      :host > .In > .In > .In{\n        display: table-cell;\n        vertical-align: middle;\n        text-align: center;\n        font-size: 16px;\n        color: #28344f;\n        padding: 0 20px;\n      }\n      </style>\n\n      <div class=\"In\">\n        <div class=\"Bg\">\n          <div class=\"t\">&nbsp;</div>\n          <div class=\"m\">&nbsp;</div>\n          <div class=\"b\">&nbsp;</div>\n        </div>\n        <div class=\"In\"><div class=\"In\" data-role=\"text\">[[text]]</div></div>\n      </div>\n\n      <div style=\"padding-top:56px;\">\n\n      </div>\n      "]);

    _templateObject_d7415600495211e98f33d7313858de80 = function _templateObject_d7415600495211e98f33d7313858de80() {
      return data;
    };

    return data;
  }

  {
    var _browser = typeof browser !== 'undefined' ? browser : chrome; // Get data from locales through chrome.i18n.getMessage


    var internationalize = function internationalize(key
    /*: string*/
    )
    /*:  string*/
    {
      try {
        return _browser.i18n.getMessage(key) || key;
      } catch (error) {
        // Firefox
        return key;
      }
    };

    var text
    /*: string*/
    = internationalize('browsec_can_work_in_private_mode');

    var PopupPrivateMode =
    /*#__PURE__*/
    function (_PolymerElement) {
      babelHelpers.inherits(PopupPrivateMode, _PolymerElement);

      function PopupPrivateMode() {
        babelHelpers.classCallCheck(this, PopupPrivateMode);
        return babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(PopupPrivateMode).apply(this, arguments));
      }

      babelHelpers.createClass(PopupPrivateMode, [{
        key: "ready",
        // Lifecycle
        value: function ready() {
          babelHelpers.get(babelHelpers.getPrototypeOf(PopupPrivateMode.prototype), "ready", this).call(this);
          var textElement
          /*: HTMLElement*/
          = this.shadowRoot.querySelector('[data-role="text"]');
          var nodes
          /*: Array<Node>*/
          = text.split(/\n/).reduce(function (carry, string, index, array) {
            if (string) carry.push(document.createTextNode(string));

            if (index !== array.length - 1) {
              carry.push(document.createElement('br'));
            }

            return carry;
          }, []);
          nodes.forEach(function (node) {
            textElement.appendChild(node);
          });
        }
      }], [{
        key: "template",
        get: function get() {
          return (0, _head.html)(_templateObject_d7415600495211e98f33d7313858de80());
        }
      }]);
      return PopupPrivateMode;
    }(_head.PolymerElement);

    customElements.define('popup-private-mode', PopupPrivateMode);
  }
});