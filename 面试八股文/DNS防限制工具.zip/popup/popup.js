(function () {
  var _browser = typeof browser !== 'undefined' ? browser : chrome;

  var backgroundPage = _browser.extension.getBackgroundPage();

  if (!backgroundPage) {
    // Firefox private mode
    var parent
    /*: HTMLElement | null*/
    = document.querySelector('div.MainContainer');
    if (!parent) return;
    parent.appendChild(document.createElement('main-head'));
    parent.appendChild(document.createElement('popup-private-mode'));
    return;
  } // Normal case


  var _ = backgroundPage._,
      account = backgroundPage.account,
      Browser = backgroundPage.Browser,
      Counters = backgroundPage.Counters,
      DelayRecord = backgroundPage.DelayRecord,
      ga = backgroundPage.ga,
      proxy = backgroundPage.proxy,
      ShowedOffers = backgroundPage['showedOffers'],
      storage = backgroundPage.storage,
      store = backgroundPage.store,
      windowErrorHandler = backgroundPage.windowErrorHandler;
  var pageLoadTimer = new DelayRecord('Popup: page load');
  window._ = _;
  window.onerror = windowErrorHandler; // Show speed banner

  window.showSpeedPromo = function () {
    var _store$getState$pac = store.getState().pac,
        filters = _store$getState$pac.filters,
        mode = _store$getState$pac.mode;
    return mode === 'proxy' || filters.some(function (_ref) {
      var disabled = _ref.disabled,
          proxyMode = _ref.proxyMode;
      return !disabled && proxyMode;
    });
  }();
  /*::( window.showSpeedPromo: boolean );*/


  if (store.getState().page !== 'index:home') {
    store.dispatch({
      'type': 'Page change',
      'page': 'index:home'
    }); // NOTE critical
  }

  Counters.increase('icon clicks');
  account.load(); // On each popup open every 5 minutes load account to check
  // First popup open

  if (storage.get('firstPopupOpen') === 'installed') {
    ga({
      'category': 'extension',
      'action': 'first_popup_open'
    });
    storage.set('firstPopupOpen', 'fulfilled');
  }

  var congratsTabId
  /*: integer*/
  = storage.get('congrats_tab_id'); // Is congratulation tab open?

  var tabOpenPromise
  /*: Promise<boolean>*/
  = Promise.resolve(false);

  if (congratsTabId) {
    tabOpenPromise = Browser.tabs.query().then(function (tabs) {
      return tabs.some(function (_ref2) {
        var id = _ref2.id;
        return id === congratsTabId;
      });
    });
  } // If user has no trial premium token -> show new apps page


  babelHelpers.asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee() {
    var condition, tabOpen;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            condition
            /*: boolean*/
            = !ShowedOffers.includes('apps page') && storage.get('installBrowsecOnMobile') === 'ready';

            if (condition) {
              _context.next = 3;
              break;
            }

            return _context.abrupt("return");

          case 3:
            _context.next = 5;
            return tabOpenPromise;

          case 5:
            tabOpen
            /*: boolean*/
            = _context.sent;

            if (tabOpen) {
              Browser.tabs.update(congratsTabId, {
                'url': '/offers/install_browsec_on_mobile.html'
              });
            } else {
              Browser.tabs.create('/offers/install_browsec_on_mobile.html'); // Active!
            }

            ShowedOffers.push('apps page');
            storage.remove('congrats_tab_id', 'installBrowsecOnMobile');

          case 9:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, this);
  }))();
  var controlStateTimer = new DelayRecord('Popup: get control state'); // Do we have control over proxy? If true -> we do

  var controlStatePromise
  /*: Promise<boolean>*/
  = babelHelpers.asyncToGenerator(
  /*#__PURE__*/
  regeneratorRuntime.mark(function _callee2() {
    var controlState;
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            if (!(!proxy.getControlState || !store.getState().pac.broken)) {
              _context2.next = 2;
              break;
            }

            return _context2.abrupt("return", true);

          case 2:
            _context2.next = 4;
            return proxy.getControlState();

          case 4:
            controlState
            /*: boolean*/
            = _context2.sent;

            if (controlState) {
              _context2.next = 7;
              break;
            }

            return _context2.abrupt("return", false);

          case 7:
            _context2.next = 9;
            return proxy.setState({
              'broken': false
            });

          case 9:
            return _context2.abrupt("return", true);

          case 10:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }))();
  controlStatePromise.then(function () {
    controlStateTimer.end();
  });
  var webComponentsTimer = new DelayRecord('Popup: web components'); // when Polymer is ready

  var polymerReadyPromise = new Promise(function (resolve) {
    window.addEventListener('WebComponentsReady', resolve);
  });
  polymerReadyPromise.then(function () {
    webComponentsTimer.end();
  });
  Promise.all([controlStatePromise, polymerReadyPromise]).then(function (_ref5) {
    var _ref6 = babelHelpers.slicedToArray(_ref5, 1),
        controlState = _ref6[0];

    var parent
    /*: HTMLElement | null*/
    = document.querySelector('div.MainContainer');
    if (!parent) return;
    var appendElementsTimer = new DelayRecord('Popup: append elements');
    var elements
    /*: Array<string>*/
    = ['main-head', 'page-switch'];
    if (!controlState) elements.push('popup-proxy-blocked');
    elements.forEach(function (element) {
      parent.appendChild(document.createElement(element));
    });
    appendElementsTimer.end();
    pageLoadTimer.end();
  }); // PolymerRedux problems resolve

  window.addEventListener('unload', function () {
    if (!document.body) return; // Flow crap

    Array.from(document.body.children).forEach(function (element) {
      if (element.tagName.toLowerCase() === 'script') return;
      if (document.body) document.body.removeChild(element); // Flow crap
    });
  });
})();