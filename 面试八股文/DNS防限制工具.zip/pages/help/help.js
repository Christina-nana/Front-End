// @flow

/** Separate page */
var _browser = typeof browser !== 'undefined' ? browser : chrome;

var backgroundPage = _browser.extension.getBackgroundPage();

if (backgroundPage) {
  var internationalize = backgroundPage['tools'].internationalize;
  document.title = internationalize('how_to_use_smart_settings');
}