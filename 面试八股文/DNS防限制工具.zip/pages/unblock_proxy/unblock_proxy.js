// @flow
// Separate page
var _browser = typeof browser !== 'undefined' ? browser : chrome;

var backgroundPage = _browser.extension.getBackgroundPage();

if (backgroundPage) {
  var internationalize = backgroundPage['tools'].internationalize;
  document.title = internationalize('your_proxy_settings_are_blocked');
}